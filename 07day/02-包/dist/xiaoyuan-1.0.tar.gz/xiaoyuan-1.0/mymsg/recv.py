#coding=utf-8
def recvmsg():
    print("接短信")
