#coding=utf-8
def sendmsg():
    print("发短信")
