from distutils.core import setup
setup(name="xiaoyuan", version="1.0", description="xiaoyuan's module", author="xiaoyuan", py_modules=["mymsg.send","mymsg.recv"])
